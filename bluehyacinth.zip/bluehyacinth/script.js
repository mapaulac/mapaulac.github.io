function showThis(){
  console.log("HOVERING OVER");
  document.getElementById("square-container").style.cursor = "pointer";
  document.getElementById("text1").style.display = "block";
  document.getElementById("text2").style.display = "none";
  document.getElementById("text3").style.display = "none";
  document.getElementById("text4").style.display = "none";
}

function showThis2(){
  console.log("HOVERING OVER 2");
  document.getElementById("square-container").style.cursor = "pointer";
  document.getElementById("text1").style.display = "none";
  document.getElementById("text2").style.display = "block";
  document.getElementById("text3").style.display = "none";
  document.getElementById("text4").style.display = "none";
}

function showThis3(){
  console.log("HOVERING OVER 3");
  document.getElementById("square-container").style.cursor = "pointer";
  document.getElementById("text1").style.display = "none";
  document.getElementById("text2").style.display = "none";
  document.getElementById("text3").style.display = "block";
  document.getElementById("text4").style.display = "none";
}

function showThis4(){
  console.log("HOVERING OVER 4");
  document.getElementById("square-container").style.cursor = "pointer";
  document.getElementById("text1").style.display = "none";
  document.getElementById("text2").style.display = "none";
  document.getElementById("text3").style.display = "none";
  document.getElementById("text4").style.display = "block";
}
